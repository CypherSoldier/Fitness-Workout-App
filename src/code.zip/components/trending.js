import React, { useState, useEffect } from 'react';

function TrendingPage() {
  const [trendingWorkouts, setTrendingWorkouts] = useState([]);
  const [selectedWorkout, setSelectedWorkout] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Mock trending workouts data
  const mockTrendingData = [
    {
      id: 1,
      name: "30-Minute Full Body HIIT",
      emoji: "💪",
      difficulty: "Intermediate",
      duration: "30 min",
      calories: "300-400",
      popularity: 95,
      description: "High-intensity interval training targeting all major muscle groups",
      exercises: ["Burpees", "Mountain Climbers", "Jump Squats", "Push-ups", "Plank"]
    },
    {
      id: 2,
      name: "Cardio Burn Express",
      emoji: "🏃‍♂️",
      difficulty: "Beginner",
      duration: "20 min",
      calories: "200-300",
      popularity: 88,
      description: "Quick cardio session to boost metabolism and burn calories",
      exercises: ["Jumping Jacks", "High Knees", "Butt Kicks", "Sprint Intervals"]
    },
    {
      id: 3,
      name: "Morning Yoga Stretch",
      emoji: "🧘‍♀️",
      difficulty: "Beginner",
      duration: "15 min",
      calories: "50-100",
      popularity: 92,
      description: "Gentle morning routine to improve flexibility and mindfulness",
      exercises: ["Sun Salutation", "Cat-Cow", "Child's Pose", "Warrior II"]
    },
    {
      id: 4,
      name: "Strength Training Basics",
      emoji: "🏋️",
      difficulty: "Beginner",
      duration: "45 min",
      calories: "250-350",
      popularity: 85,
      description: "Build foundational strength with basic compound movements",
      exercises: ["Squats", "Deadlifts", "Bench Press", "Rows", "Overhead Press"]
    },
    {
      id: 5,
      name: "Core Crusher Challenge",
      emoji: "🥵",
      difficulty: "Advanced",
      duration: "25 min",
      calories: "200-250",
      popularity: 90,
      description: "Intense core workout to build abdominal strength and stability",
      exercises: ["Plank Variations", "Russian Twists", "Bicycle Crunches", "Leg Raises"]
    }
  ];

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setTrendingWorkouts(mockTrendingData.sort((a, b) => b.popularity - a.popularity));
      setIsLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, []);

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner': return '#4ade80';
      case 'Intermediate': return '#fbbf24';
      case 'Advanced': return '#ef4444';
      default: return '#6b7280';
    }
  };

  if (isLoading) {
    return (
      <div className="fitness">
        <div className="main-board">
          <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center',
            color: 'white',
            height: '80vh'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ 
                width: '50px', 
                height: '50px', 
                border: '4px solid rgba(17,183,122,.3)',
                borderTop: '4px solid rgba(17,183,122,.856)',
                borderRadius: '50%',
                animation: 'spin 1s linear infinite',
                margin: '0 auto 20px'
              }}></div>
              <p>Loading trending workouts...</p>
            </div>
          </div>
        </div>
        <style>
          {`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}
        </style>
      </div>
    );
  }

  return (
    <div className="fitness">
      <div className="main-board">
        <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
          <header style={{ textAlign: 'center', marginBottom: '40px', paddingTop: '20px' }}>
            <h1 style={{ 
              fontSize: '3rem', 
              marginBottom: '10px',
              background: 'linear-gradient(135deg, rgba(17,183,122,.856) 0%, #4ade80 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              color: 'rgba(17,183,122,.856)' // fallback
            }}>
              🔥 Trending Workouts
            </h1>
            <p style={{ fontSize: '1.2rem', color: '#9ca3af' }}>
              Discover the most popular workouts this week
            </p>
          </header>

          <div className="days">
            {trendingWorkouts.map((workout, index) => (
              <div
                key={workout.id}
                style={{
                  backgroundColor: '#191a1c',
                  borderRadius: '15px',
                  padding: '25px',
                  margin: '15px',
                  minWidth: '320px',
                  maxWidth: '400px',
                  position: 'relative',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  border: selectedWorkout?.id === workout.id ? '2px solid rgba(17,183,122,.856)' : '2px solid transparent',
                  transform: selectedWorkout?.id === workout.id ? 'scale(1.02)' : 'scale(1)',
                  boxShadow: selectedWorkout?.id === workout.id ? '0 10px 30px rgba(17,183,122,.3)' : '0 5px 15px rgba(0,0,0,0.3)'
                }}
                onClick={() => setSelectedWorkout(selectedWorkout?.id === workout.id ? null : workout)}
                onMouseEnter={(e) => {
                  if (selectedWorkout?.id !== workout.id) {
                    e.currentTarget.style.transform = 'scale(1.02)';
                    e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.4)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedWorkout?.id !== workout.id) {
                    e.currentTarget.style.transform = 'scale(1)';
                    e.currentTarget.style.boxShadow = '0 5px 15px rgba(0,0,0,0.3)';
                  }
                }}
              >
                <div style={{ 
                  position: 'absolute', 
                  top: '15px', 
                  right: '15px',
                  backgroundColor: 'rgba(17,183,122,.856)',
                  borderRadius: '20px',
                  padding: '5px 12px',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  color: 'white'
                }}>
                  #{index + 1}
                </div>

                <div style={{ display: 'flex', alignItems: 'center', marginBottom: '15px' }}>
                  <span style={{ fontSize: '2.5rem', marginRight: '15px' }}>{workout.emoji}</span>
                  <div>
                    <h3 style={{ 
                      fontSize: '1.5rem', 
                      marginBottom: '5px',
                      color: 'white',
                      margin: '0 0 5px 0'
                    }}>
                      {workout.name}
                    </h3>
                    <div style={{ display: 'flex', gap: '15px', alignItems: 'center', flexWrap: 'wrap' }}>
                      <span style={{ 
                        color: getDifficultyColor(workout.difficulty),
                        fontWeight: 'bold',
                        fontSize: '14px'
                      }}>
                        {workout.difficulty}
                      </span>
                      <span style={{ color: '#9ca3af', fontSize: '14px' }}>
                        ⏱️ {workout.duration}
                      </span>
                      <span style={{ color: '#9ca3af', fontSize: '14px' }}>
                        🔥 {workout.calories} cal
                      </span>
                    </div>
                  </div>
                </div>

                <p style={{ 
                  color: '#d1d5db', 
                  marginBottom: '20px',
                  lineHeight: '1.5'
                }}>
                  {workout.description}
                </p>

                <div style={{ marginBottom: '20px' }}>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    marginBottom: '8px'
                  }}>
                    <span style={{ fontSize: '14px', color: '#9ca3af' }}>Popularity</span>
                    <span style={{ fontSize: '14px', fontWeight: 'bold', color: 'rgba(17,183,122,.856)' }}>
                      {workout.popularity}%
                    </span>
                  </div>
                  <div style={{ 
                    width: '100%', 
                    height: '8px', 
                    backgroundColor: '#374151', 
                    borderRadius: '4px',
                    overflow: 'hidden'
                  }}>
                    <div style={{ 
                      width: `${workout.popularity}%`, 
                      height: '100%', 
                      backgroundColor: 'rgba(17,183,122,.856)',
                      borderRadius: '4px',
                      transition: 'width 0.5s ease'
                    }}></div>
                  </div>
                </div>

                {selectedWorkout?.id === workout.id && (
                  <div style={{
                    borderTop: '1px solid #374151',
                    paddingTop: '20px',
                    animation: 'fadeIn 0.3s ease'
                  }}>
                    <h4 style={{ 
                      color: 'rgba(17,183,122,.856)', 
                      marginBottom: '12px',
                      fontSize: '1.1rem'
                    }}>
                      Exercises Include:
                    </h4>
                    <div style={{ 
                      display: 'flex', 
                      flexWrap: 'wrap', 
                      gap: '8px',
                      marginBottom: '15px'
                    }}>
                      {workout.exercises.map((exercise, idx) => (
                        <span
                          key={idx}
                          style={{
                            backgroundColor: '#374151',
                            color: 'white',
                            padding: '6px 12px',
                            borderRadius: '20px',
                            fontSize: '13px',
                            border: '1px solid #4b5563'
                          }}
                        >
                          {exercise}
                        </span>
                      ))}
                    </div>
                    <button
                      className="save"
                      style={{
                        width: '100%',
                        padding: '12px 24px',
                        fontSize: '16px',
                        fontWeight: 'bold',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        color: 'white'
                      }}
                      onMouseEnter={(e) => {
                        e.target.style.backgroundColor = 'rgba(17,183,122,1)';
                        e.target.style.transform = 'translateY(-1px)';
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.backgroundColor = 'rgba(17,183,122,.856)';
                        e.target.style.transform = 'translateY(0)';
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        alert(`Starting ${workout.name}! This would integrate with your workout system.`);
                      }}
                    >
                      Start Workout ▶️
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <style>
          {`
            @keyframes fadeIn {
              from { opacity: 0; transform: translateY(10px); }
              to { opacity: 1; transform: translateY(0); }
            }
          `}
        </style>
      </div>
    </div>
  );
}

export default TrendingPage;